# Mohd Saad Portfolio

Files:
- index.html — responsive portfolio
- style.css — responsive styling
- script.js — mobile navigation
- Mohd_Saad_Resume.pdf — resume
- assets/ — supplied profile/certificate/project images

## iPhone publishing
1. Open GitHub in Safari and sign in.
2. Create a new public repository, e.g. `mohd-saad-portfolio`.
3. Upload `index.html`, `style.css`, `script.js`, `Mohd_Saad_Resume.pdf`, and the entire `assets` folder.
4. In repository Settings → Pages, choose Deploy from branch → main → root.
5. GitHub will provide the live `github.io` URL.

No Class 12 qualification is listed because the user stated it was not completed.
